#include <iostream>
#include "PartialDigester.h"
#include "Substring.h"
#include "Profiler.h"
#include "PDP.h"

int main() {
    std::vector<int> L = { 2, 2, 3, 3, 4, 5, 6, 7, 8, 10 };
    std::vector<int> L2 = { 1, 2, 2, 3, 5, 6, 7, 8, 8, 10 };
    std::vector<int> problem1 = {1, 2, 2, 4, 5, 6, 7, 8, 9, 10 };
    std::vector<int> problem2 = {1, 1, 1, 2, 2, 3, 3, 3, 4, 4, 5, 5, 6, 6, 6, 9, 9, 10, 11, 12, 15 };

    std::cout << "PROBLEM 1: \n";
    PDP pdp1(problem1);


    std::cout << "\nPROBLEM 2: \n";
    PDP pdp2(problem2);


    std::cout << "\nPROBLEM 4: \n";
    Profiler profiler;
    std::cout << "Profile Matrix:\n";
    profiler.printProfileMatrix();

    // Problem 5
    std::cout << "\nPROBLEM 5: \n";
    Substring str("How Are You.", "Are");
    std::cout << "Substring = Are, Parent string = How are you.\nIndex of "
                 "Are in How are you is: ";
    std::cout << str.indexOfFirstSubstring() << '\n';






    return 0;
}